//
//  GADMediationAdapterPremiumAds.h
//  PremiumAdsAdapter
//
//  Created by Alex G on 01/01/2023.
//  Copyright © 2023 PremiumAds. All rights reserved.
//

#import <GoogleMobileAds/GoogleMobileAds.h>
#import <Foundation/Foundation.h>


@interface GADMediationAdapterPremiumAds : NSObject <GADMediationAdapter> {

}

@end
